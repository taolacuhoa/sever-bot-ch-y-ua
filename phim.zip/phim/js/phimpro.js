$(function() {

	phimso_com();

	comment();

});

function ShowMes(msg) {

    var html, debug;

    $(".pop_up").remove();

    html = "<div id='phimso_message' class='pop_up'><p>" + msg + "</p></div>";

    $(html).appendTo("#sticky_box").slideDown();

    setTimeout(RemoveMes, 30000);

    $("#phimso_message").click(function() {

        RemoveMes();

    });

}



function ShowMes_forever(msg) {

    var html, debug;

    $(".pop_up").remove();

    html = "<div id='message_forever' class='pop_up'><p>" + msg + "</p></div>";

    $(html).appendTo("#sticky_box").slideDown();

}



function RemoveMes() {

    $(".pop_up").slideUp("slow", function() {

        $(this).hide();

    });

}

function phimso_com() {

	$(".formvalidate").validate();

	$(".formvalidate1").validate();

	$.autoScroll({

	    scrollDuration: 1000,

	    showDuration: 600,

	    hideDuration: 300

	  });

	$('.top').click(function(){

		$('html, body').animate({scrollTop:0}, 'slow');

		return false;

	});  

	$(".menu").lavaLamp({ fx: "backout", speed: 700 });



	/* ManhTienpt: Search */ 

	$("#btn_submit").click(function() {

			var film_type = $("input[name='type']:checked").val(); 

			var keyword = $("input[name='keyword']").val();
			document.location = "/phimpro/dvd/tim-kiem/"+film_type+"/"+keyword+".html";
			/*
			 $.get("/phimpro/dvd/search/"+film_type+"/"+keyword+".html",

				function(data) {

					if(data.length > 0) {

						$("input[name='keyword']").addClass('loadding');

						window.location=data;

						}

					else {

						$("input[name='keyword']").addClass('error');

						}

				}

			);
			*/
		});

	$("input[name='keyword']").keypress(function (e) {  

		 if ((e.which && e.which == 13) || (e.keyCode && e.keyCode == 13)) {  

			var film_type = $("input[name='type']:checked").val(); 

			var keyword = $("input[name='keyword']").val();

			 $.get("/search/"+film_type+"/"+keyword+"/",

				function(data) {

					if(data.length > 0) {

						$("input[name='keyword']").addClass('loadding');

						window.location=data;

						}

					else {

						$("input[name='keyword']").addClass('error');

						}

				});

		 }

	});

	/* ManhTienpt: Change #play episode */ 

	$('.vietpro').click(function() {
			document.location = $(this).attr('href');
			/*
			ShowMes('Đang tải dữ liệu, vui lòng chờ xíu !!!');

			$('.vietpro').removeClass('playing');

			$('html, body').animate({scrollTop:180}, 'slow');

			var episode_id = $(this).attr('id');

			$(this).addClass('playing');

			 $.get("/episode/"+episode_id+"/",

				function(data) {

					if(data.length > 0) {

						$('#play').html(data).slideDown('fast');

						$("a[ajax='error']").attr({

							href:"/error/"+episode_id+"/"

						});

						setTimeout(RemoveMes, 1000);

						}

					else {

						$('#play').html('<span>Không tìm thấy phim</span>').slideDown('fast');

						}

				}

			);
			*/
			 return false;

		});

	$('#email').click(function() {

		$('.share').slideUp('slow');

		$('.email').slideDown('slow');

		return false;

	});

	$('#comment').click(function() {

		$('.share').slideUp('slow');

		$('.comment').slideDown('slow');

		return false;

	});

	$('#ratestar').click(function() {

		$('.share').slideUp('slow');

		$('.ratestar').slideDown('slow');

		return false;

	});

	$('#friend').click(function() {

		$('.share').slideUp('slow');

		$('.friend').slideDown('slow');

		return false;

	});

	$('#download').click(function() {

		$('.share').slideUp('slow');

		$('.download').slideDown('slow');

		return false;

	});

	$('#share_blog').click(function() {

		$('.share').slideUp('slow');

		$('.share_blog').slideDown('slow');

		return false;

	});

	$('#error').click(function() {

		$('.share').slideUp('slow');

		$('.error').slideDown('slow');

		return false;

	});

	$('.xclose').click(function() {

		$('.share').slideUp('slow');

		return false;

	});

	

	$('.send_mail').click(function(){

		$('.tb_mail').html('');

		$('.tb_mail').addClass('loadding');

		var your_name = $("input[name='your_name']").val(); 

		var list_mail = $("input[name='email_friend']").val();

		if(your_name == '') your_name = '0';

		if(list_mail == '') list_mail = '0';

		$.get("/sendmail/"+your_name+"/"+list_mail+"/",

				function(data){

			if(data.length>0){

				$('.tb_mail').html(data).slideDown('slow');

				$('.tb_mail').removeClass('loadding');

			} else {

				$('.tb_mail').html('Gửi mail không thành công, mong bạn thử lại.').slideDown('slow');

				$('.tb_mail').removeClass('loadding');

			}

		});

		return false;

	});

	$('.comment_submit').click(function(){

		$('.tb_comment').html('');

		$('.tb_comment').addClass('loadding');

		var film_id = $("input[name='film_id']").val(); 

		var comment_name = $("input[name='comment_name']").val(); 

		var comment_email = $("input[name='comment_email']").val();

		var comment_content = $("textarea[name='comment_content']").val();

		if(comment_name == '') comment_name = '0';

		if(comment_email == '') comment_email = '0';

		if(comment_content == '') comment_content = '0';

		$.get("/comment/"+film_id+"/"+comment_name+"/"+comment_email+"/"+comment_content+"/",

				function(data){

			if(data.length>0){

				$('.tb_comment').html(data).slideDown('slow');

				$('.tb_comment').removeClass('loadding');

				$("ul[class='comment']").addClass('loadding');

				$.get("/ajaxcomment/"+film_id+"/"+comment_name+"/"+comment_email+"/"+comment_content+"/",

						function(data){

							setTimeout(function(){

								$("ul[class='comment loadding']").prepend(data).slideDown('slow');

								$("ul[class='comment loadding']").removeClass('loadding');

								}, 1000);

							

						});

			} else {

				$('.tb_comment').html('Gửi cảm nhận không thành công, mong bạn thử lại.').slideDown('slow');

				$('.tb_comment').removeClass('loadding');

			}

		});

		return false;

	});



	$('.copy_submit').click(function(){

		$('.tb_copy').addClass('loadding');

		var link = $("input[name='link_copy']").val();

		$.copy(link);

		$('.tb_copy').html('Đã copy link vào bộ nhớ, bạn có thể dán(paste) và gửi cho bạn bè.').slideDown('slow');

		$('.tb_copy').removeClass('loadding');

		return false;

	});

	

	$("a[ajax='error']").click(function(){

		$('.ep_error').html('');

		$('.ep_error').addClass('loadding');

		var link_error = $(this).attr("href");

		$.get(link_error, function(data){

			if(data.length > 0){

				$('.ep_error').prepend(data).slideDown('slow');

				$('.ep_error').removeClass('loadding');

			}

			else {

				$('.ep_error').prepend('<span>Lỗi, mong bạn thử lại.</span>').slideDown('slow');

				$('.ep_error').removeClass('loadding');

			}

		});

		return false;

	});

	/* ManhTienpt:  RATE STAR */ 

	

	$('.rate_submit').click(function(){

		

		$('.rate_loading').addClass('loadding');

		$('.rate_loading').html('Đang tải dữ liệu ...');

		var content 				= $('.rate_lage').contents();

		var phim_id 				= parseInt($("input[name='film_id']").val());

		var noidung_phim 			= parseInt($("input[name='poll-1']").val());

		var chatluong_phim 			= parseInt($("input[name='poll-2']").val());

		var kyxao_phim 				= parseInt($("input[name='poll-3']").val());

		var dienxuat_phim 			= parseInt($("input[name='poll-4']").val());

		var camnhan_phim 			= parseInt($("input[name='poll-5']").val());

		var rating 					= parseInt($(".attr_rate").attr("vietpro_rating"));

		var rating_total			= parseInt($(".attr_rate").attr("vietpro_rating_total"));

		var vietpro_rating 			= parseInt(rating + noidung_phim + chatluong_phim + kyxao_phim + dienxuat_phim + camnhan_phim);

		var vietpro_rating_total 	= parseInt(rating_total + 1);

		

		$.get("/rating/"+phim_id+"/"+noidung_phim+"/"+chatluong_phim+"/"+kyxao_phim+"/"+dienxuat_phim+"/"+camnhan_phim+"/", function(data){

			if(data.length > 0) {

				$('.rate_loading').html(data).fadeIn(300);

				$('.rate_loading').removeClass('loadding');

				$('.rate_lage').addClass('loadding');

				$('.rate_lage').html('Đang tải dữ liệu ...');

				$(".attr_rate").attr({

					vietpro_rating: vietpro_rating,

					vietpro_rating_total: vietpro_rating_total

				});

				var current_rating 			= $(".attr_rate").attr("vietpro_rating"); 

				var current_rating_total	= $(".attr_rate").attr("vietpro_rating_total");

				$.get("/showrating/"+phim_id+"/"+current_rating+"/"+current_rating_total+"/"+noidung_phim+"/"+chatluong_phim+"/"+kyxao_phim+"/"+dienxuat_phim+"/"+camnhan_phim+"/", function(data){

					if(data.length > 0) {

						$('.rate_lage').removeClass('loadding');

						$('.rate_lage').html(data).fadeIn(1000);

					} 

					else {

						$('.rate_lage').removeClass('loadding');

						$('.rate_lage').html(content).fadeIn(1000);

					}

				});

			}

			else {

				$('.rate_lage').append('<span>Lỗi, mong bạn thử lại.</span>').fadeIn(300);

				$('.rate_lage').removeClass('loadding');

			}

		});

		return false;

	});

	

	

	var $caption, $cap = $("<span/>").addClass("caption");



	$(".multiField").children().hide();





	// Poll-1

	$caption = $cap.clone();

	$("#noidung-phim")

		.stars({

			cancelValue: 999,

			cancelShow: false,

			captionEl: $caption

		})

		.append($caption);



	// Poll-2

	$caption = $cap.clone();

	$("#chatluong-phim")

		.stars({

			cancelValue: 999,

			cancelShow: false,

			captionEl: $caption

		})

		.append($caption);



	// Poll-3

	$caption = $cap.clone();

	$("#kyxao-phim")

		.stars({

			cancelValue: 999,

			cancelShow: false,

			captionEl: $caption

		})

		.append($caption);



	// Poll-4

	$caption = $cap.clone();

	$("#dienxuat-phim")

		.stars({

			cancelValue: 999,

			cancelShow: false,

			captionEl: $caption

		})

		.append($caption);



	// Poll-5

	$caption = $cap.clone();

	$("#camnhan-phim")

		.stars({

			cancelValue: 999,

			cancelShow: false,

			captionEl: $caption

		})

		.append($caption);

	// Ket thuc RATE STAR

	

	

} /* ManhTienpt:  ket thuc ham */ 

function comment(){

	$("a[ajax='yes']").click(function(){

		$(".load").addClass('loadding');

		$('.mt_comment').html('').slideUp('slow');

		$('.load').html("Đang tải dữ liệu ...");

		var link_page = $(this).attr('href');

		$.get(link_page, function(data){

			if(data.length>0){ 

				$('.mt_comment').html(data).slideDown('slow');

				$('.load').html("");

				$(".load").removeClass('loadding');

				comment();

			}

			else {

				$('.mt_comment').html('Không tồn tại trang này.').slideDown('slow');

				$(".load").removeClass('loadding');

			}

		});

		return false;

	});

}

(function(jq) {

    jq.autoScroll = function(ops) {

        ops = ops || {};

        ops.styleClass = ops.styleClass || 'scroll-to-top-button';

        var t = jq('<div class="'+ops.styleClass+'"></div>'),

            d = jq(ops.target || document);

        jq(ops.container || 'body').append(t);



        t.css({

            opacity: 0,

            position: 'absolute',

            top: 0,

            right: 0

        }).click(function() {

            jq('html,body').animate({

                scrollTop: 0

            }, ops.scrollDuration || 1000);

        });



        d.scroll(function() {

            var sv = d.scrollTop();

            if (sv < 10) {

                t.clearQueue().fadeOut(ops.hideDuration || 200);

                return;

            }



            t.css('display', '').clearQueue().animate({

                top: sv + 450,

                opacity: 0.5

            }, ops.showDuration || 500);

        });

    };

})(jQuery);