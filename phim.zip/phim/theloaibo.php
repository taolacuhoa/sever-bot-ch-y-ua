﻿<?
class cURL {
var $headers;
var $user_agent;
var $compression;
var $cookie_file;
var $proxy;
function cURL($cookies=TRUE,$cookie='cook.txt',$compression='gzip',$proxy='') {
$this->headers[] = 'Accept: image/gif, image/x-bitmap, image/jpeg, image/pjpeg';
$this->headers[] = 'Connection: Keep-Alive';
$this->headers[] = 'Content-type: application/x-www-form-urlencoded;charset=UTF-8';
$this->user_agent = 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 1.0.3705; .NET CLR 1.1.4322; Media Center PC 4.0)';
$this->compression=$compression;
$this->proxy=$proxy;
$this->cookies=$cookies;
if ($this->cookies == TRUE) $this->cookie($cookie);
}
function cookie($cookie_file) {
if (file_exists($cookie_file)) {
$this->cookie_file=$cookie_file;
} else {
fopen($cookie_file,'w') or $this->error('The cookie file could not be opened. Make sure this directory has the correct permissions');
$this->cookie_file=$cookie_file;
//fclose($this->cookie_file);
}
}
function get($url) {
$process = curl_init($url);
curl_setopt($process, CURLOPT_HTTPHEADER, $this->headers);
curl_setopt($process, CURLOPT_HEADER, 0);
curl_setopt($process, CURLOPT_USERAGENT, $this->user_agent);
if ($this->cookies == TRUE) curl_setopt($process, CURLOPT_COOKIEFILE, $this->cookie_file);
if ($this->cookies == TRUE) curl_setopt($process, CURLOPT_COOKIEJAR, $this->cookie_file);
curl_setopt($process,CURLOPT_ENCODING , $this->compression);
curl_setopt($process, CURLOPT_TIMEOUT, 30);
//if ($this->proxy) curl_setopt($cUrl, CURLOPT_PROXY, ‘proxy_ip:proxy_port’);
curl_setopt($process, CURLOPT_RETURNTRANSFER, 1);
//curl_setopt($process, CURLOPT_FOLLOWLOCATION, 1);
$return = curl_exec($process);
curl_close($process);
return $return;
}
function post($url,$data) {
$process = curl_init($url);
curl_setopt($process, CURLOPT_HTTPHEADER, $this->headers);
curl_setopt($process, CURLOPT_HEADER, 1);
curl_setopt($process, CURLOPT_USERAGENT, $this->user_agent);
if ($this->cookies == TRUE) curl_setopt($process, CURLOPT_COOKIEFILE, $this->cookie_file);
if ($this->cookies == TRUE) curl_setopt($process, CURLOPT_COOKIEJAR, $this->cookie_file);
curl_setopt($process, CURLOPT_ENCODING , $this->compression);
curl_setopt($process, CURLOPT_TIMEOUT, 30);
if ($this->proxy) curl_setopt($process, CURLOPT_PROXY, $this->proxy);
curl_setopt($process, CURLOPT_POSTFIELDS, $data);
curl_setopt($process, CURLOPT_RETURNTRANSFER, 1);
//curl_setopt($process, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($process, CURLOPT_POST, 1);
$return = curl_exec($process);
curl_close($process);
return $return;
}
function error($error) {
echo "<center><div style='width:500px;border: 3px solid #FFEEFF; padding: 3px; background-color: #FFDDFF;font-family: verdana; font-size: 10px'><b>cURL Error</b><br>$error</div></center>";
die;
}
}
$cc = new cURL();
$id = $_GET['id'];
$id = str_replace('/','/',$id);
$id = str_replace('-','-',$id);
$id = str_replace('&','&',$id);
$url = "http://megafun.vn/".$id;
if(!$id)$url="http://megafun.vn/giai-tri/phim-hai/201008/Tuyet-dinh-cong-phu-89761/";
$htm = $cc->get($url);
$code = explode('flashvars="file=/',$htm);
$code = explode('&streamer=',$code[1]);
$codename = explode('id="title">',$htm);
$codename = explode('</h1>',$codename[1]);
$codename = $codename[0];
$lienquan = explode('<div class="movie-list-container other-genre">',$htm);
$lienquan = explode('<div class="col2">',$lienquan[1]);
$lienquan = str_replace('<h2>','<b>',$lienquan);
$lienquan = str_replace('</h2>','</b>',$lienquan);
$lienquan = str_replace('/dataimages','http://megafun.vn/dataimages',$lienquan);
$lienquan = str_replace('<img','<img width=150 height=120',$lienquan);
$lienquan = str_replace('<a href="/giai-tri/','<a href="http://vietxem.net/phim/giai-tri/',$lienquan);
$lienquan = $lienquan[0];
$code = $code[0];
//echo $code;
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>..::VietXem.Net::..., <?=$codename?> , Phim Tâm Lý Nhật Bản, Phim Tâm Lý Hàn Quốc, Phim Tâm Lý Mỹ, Phim Tâm Lý Hồng Kông, Phim Tâm Lý Thái Lan, Phim Tâm Lý Hay, Phim Tâm Lý Châu Á, xem phim online, phim nhanh, phim truc tuyen, phimvang.com</title>
<meta name="title" content="..::VietXem.Net::.., Phim Tâm Lý Nhật Bản, Phim Tâm Lý Hàn Quốc, Phim Tâm Lý Mỹ, Phim Tâm Lý Hồng Kông, Phim Tâm Lý Thái Lan, Phim Tâm Lý Hay, Phim Tâm Lý Châu Á, xem phim online, phim nhanh, phim truc tuyen, phimvang.com">
<meta name="description" content="..::VietXem.Net::.. - Nơi có những bộ phim HOT nhất, hay nhất, mới nhất. Đặc biệt là thể loại phim Tâm Lý Tình Cảm, Hành Động, Võ Thuật với nhiều phim cực kì hấp dẫn."/>
<meta name="keywords" content="..::VietXem.Net::.., Phim Tâm Lý Nhật Bản, Phim Tâm Lý Hàn Quốc, Phim Tâm Lý Mỹ, Phim Tâm Lý Hồng Kông, Phim Tâm Lý Thái Lan, Phim Tâm Lý Hay, Phim Tâm Lý Châu Á, xem phim online, phim nhanh, phim truc tuyen, Phim Hành Động, Phim Bộ, Phim Lẻ, Phim Chưởng, Phim Võ Thuật, Phim Hồng Kông, phimvang.com"/>
<meta name="robots" content="index,follow" />
<meta name="google-site-verification" content="xC8siylklhEjq17egEnOl8jhvBYV5wnqum0hRGTS2qc" />
<meta name="msvalidate.01" content="1C9874734A2C0511734729D5AFA711C3" />
<link rel="alternate" type="application/rss+xml" title="..::VietXem.Net::.., Phim Tâm Lý Nhật Bản, Phim Tâm Lý Hàn Quốc, Phim Tâm Lý Mỹ, Phim Tâm Lý Hồng Kông, Phim Tâm Lý Thái Lan, Phim Tâm Lý Hay, Phim Tâm Lý Châu Á, xem phim online, phim nhanh, phim truc tuyen, phimvang.com RSS Feed" href="http://vietxem.net/phim" />


<!-- <base href="http://vietxem.net/phim/" /> -->
<link rel="image_src" href="http://vietxem.net/phim/player/images/logo.png" />
<link rel="shortcut icon" href="http://4.bp.blogspot.com/-bKXlj3xgUiE/Td9SzqRmpfI/AAAAAAAAAGM/w2P_OVQrQ2A/s1600/favicon.png" type="image/x-icon"/>
<meta name="msapplication-task" content="name=vietxem.net/phim;action-uri=http://vietxem.net;icon-uri=http://vietxem.net/favicon.ico">
<link type="text/css" rel="stylesheet" href="css/style.css"/>
<link rel="stylesheet" href="css/nivo-slider.css" type="text/css" media="screen" />
<link type="text/css" rel="stylesheet" href="css/uni-form.css"  media="screen"/>
<link rel="stylesheet" type="text/css" href="css/jquery.ui.stars.css"/>
<!--[if lte IE 7]>
	<style type="text/css">@import "css/ie6.css";</style>
<![endif]-->  
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/phimpro.js"></script>
<script type="text/javascript" src="js/jquery.easing.min.js"></script>
<script type="text/javascript" src="js/jquery.lavalamp.min.js"></script>
<script type="text/javascript" src="js/jquery.nivo.slider.pack.js"></script>
<script type="text/javascript" src="js/jquery.validate.js"></script>
<script type="text/javascript" src="js/jquery.copy.js"></script>
<script type="text/javascript" src="js/swfobject.js"></script>
<script type="text/javascript" src="js/jquery-ui.custom.min.js"></script>
<script type="text/javascript" src="js/jquery.ui.stars.js"></script>



		<script type="text/javascript">
		$(window).load(function() {
			$('#slider').nivoSlider();
		});
		</script>
</head>

<body onLoad="checkLogin()&showphimbo('phim-bo','1')&tComment('comment');">
<div id="phimpro">
<div id="ManhTienpt">
	<div id="phimso">
		<div id="wrap">
			<div id="header">
				<div class="search">
					<div class="radio">
						<span><input type="radio" name="type" id="all" value="submit" class="submit" id="btn_submit"/>
					</div>
				</div><!-- search -->
				<ul class="menu">
                                  
					<li ><a href="http://vietxem.net/phim/" title="Trang chủ">Trang chủ</a></li>
					<li ><a href="http://vietxem.net/phim/" title="Phim mới cập nhật">Phim mới</a></li>
					<li ><a href="http://vietxem.net/phim/" title="Phim hot, phim được chú ý nhất">Phim HOT</a></li>
					<li ><a href="http://vietxem.net/phim/" title="Các bộ phim được xem nhiều nhất">Phim xem nhiều</a></li>
					<li ><a href="http://vietxem.net/phim/" title="Các bộ phim được chiếu rạp">Phim chiếu rạp</a></li>
					<li ><a href="http://vietxem.net/phim/" title="Phim được đề cử, phim hay đề cử">Phim đề cử</a></li>
					<li ><a href="http://vietxem.net/phim/" title="Phim bộ, phim bộ Việt Nam, phim bộ Hàn Quốc, Phim bộ HongKong, Phim bộ trung quốc, phim bộ Thái Lan, phim bộ châu âu, phim bộ châu mỹ, ...">Phim bộ</a></li>
					<li ><a href="http://vietxem.net/phim/" title="Phim lẻ, phim 1 tập, phim ngắn, phim nhanh">Phim lẻ</a></li>
					<li ><a href="http://vietxem.net/phim/" title="Hướng dẫn Xem Phim.">Hỏi-Đáp</a></li>
								</ul>
			</div><!-- header -->

    
<div id="main">


<div class="left">
	<div class="l1">
		<div class="l2">
			<div class="trailer">
<div id="slider" class="nivoSlider">
<a href='http://vietxem.net/phim/' title='Học Trường Mật Cảnh - Yes Sir, Sorry Sir (2011)'>
<img src='http://vietxem.net/phim/images/Hoc+truong+mat+canh.jpg'  title='Học Trường Mật Cảnh - Yes Sir, Sorry Sir (2011)' alt='Học Trường Mật Cảnh - Yes Sir, Sorry Sir (2011)' width='666' height='220'/></a>
<a href='http://vietxem.net/phim/' title='Phim Hot: Kung Fu Panda 2 - Bí Mật Của Ngũ Hùng (2011)'>
<img src='http://vietxem.net/phim/images/kung-fu-panda-2.jpg'  title='Phim Hot: Kung Fu Panda 2 - Bí Mật Của Ngũ Hùng (2011)' alt='Phim Hot: Kung Fu Panda 2 - Bí Mật Của Ngũ Hùng (2011)' width='666' height='220'/></a>
<a href='http://vietxem.net/phim/' title='Phim Hot: Baby Faced Beauty - Dongan Minyeo (2011)'>
<img src='http://vietxem.net/phim/images/Baby-faced+Beauty.jpg'  title='Phim Hot: Baby Faced Beauty - Dongan Minyeo (2011)' alt='Phim Hot: Baby Faced Beauty - Dongan Minyeo (2011)' width='666' height='220'/></a>
<a href='http://vietxem.net/phim/' title='Hồng Võ Tam Thập Nhị - Relic Of An Emissary (2011) - Pvlt - (15/30)'>
<img src='http://vietxem.net/phim/images/hong+vo+tam+thap+nhi.jpg'  title='Hồng Võ Tam Thập Nhị - Relic Of An Emissary (2011) - Pvlt - (15/30)' alt='Hồng Võ Tam Thập Nhị - Relic Of An Emissary (2011) - Pvlt - (15/30)' width='666' height='220'/></a>
<a href='http://vietxem.net/phim/' title='Cướp Biển Vùng Caribe 4 - Pirates Of The Caribbean On Stranger Tides (2011)'>
<img src='http://vietxem.net/phim/images/Cuop+bien+caribe+4.jpg'  title='Cướp Biển Vùng Caribe 4 - Pirates Of The Caribbean On Stranger Tides (2011)' alt='Cướp Biển Vùng Caribe 4 - Pirates Of The Caribbean On Stranger Tides (2011)' width='666' height='220'/></a>
<a href='http://vietxem.net/phim/' title='Phim Tâm Lý Natalie 2010 (18+)'>
<img src='http://vietxem.net/phim/images/natalie.jpg'  title='Phim Tâm Lý Natalie 2010 (18+)' alt='Phim Tâm Lý Natalie 2010 (18+)' width='666' height='220'/></a>
<a href='http://vietxem.net/phim/' title='Nhục Bồ Đoàn 3s (18+) - Sex And Zen 3d Phim 18+ 3d Đầu Tiên'>
<img src='http://vietxem.net/phim/images/sex-and-zen-3d.jpg'  title='Nhục Bồ Đoàn 3s (18+) - Sex And Zen 3d Phim 18+ 3d Đầu Tiên' alt='Nhục Bồ Đoàn 3s (18+) - Sex And Zen 3d Phim 18+ 3d Đầu Tiên' width='666' height='220'/></a>
<a href='http://vietxem.net/phim/' title='Cẩm Y Vệ - 14 Blades (2010)'>
<img src='http://vietxem.net/phim/images/Cam-y-ve-14-Blades.jpg'  title='Cẩm Y Vệ - 14 Blades (2010)' alt='Cẩm Y Vệ - 14 Blades (2010)' width='666' height='220'/></a>
<a href='http://vietxem.net/phim/' title='Kiếm Vũ: Thời Đại Sát Thủ - The Reign Of Assasins'>
<img src='http://vietxem.net/phim/images/kiem-vu.jpg'  title='Kiếm Vũ: Thời Đại Sát Thủ - The Reign Of Assasins' alt='Kiếm Vũ: Thời Đại Sát Thủ - The Reign Of Assasins' width='666' height='220'/></a>
<a href='http://vietxem.net/phim/' title='Tân Thủy Hử 2011 - All Men Are Brothers (tập 86/86)'>
<img src='http://vietxem.net/phim/images/tan-thuy-hu.jpg'  title='Tân Thủy Hử 2011 - All Men Are Brothers (tập 86/86)' alt='Tân Thủy Hử 2011 - All Men Are Brothers (tập 86/86)' width='666' height='220'/></a>

</div></div>
<div class="clear"></div>
<?php
srand((float) microtime() * 100);
$input = array("123.29.70.3" ,"123.29.70.3");
$rand_keys = array_rand($input, 2);
//echo $input[$rand_keys[0]] . "\n";
//echo $input[$rand_keys[1]] . "\n";
?>
<!-- <? echo $input[$rand_keys[0]];?> -->

<div class='box_left'>
						


                                              <div class='bar'>
							<h3><a href='#'>Media Player Phim : <?=$codename?></a></h3>
						</div>
						<div class='cont'>
							<ul>

	<center>
               <div id="KGTPlayer" name="KGTPlayer" class="text-link">Nhấn <a href="http://www.macromedia.com/go/getflashplayer/" ><font color="#FFAE00"><b>vào đây</b></font></a> để tải Macromedia Flash nếu như máy bạn chưa cài.</div>

                   <script type="text/javascript">
                    var so = new SWFObject('http://vietxem.net/play.swf', 'flash_player', '600', '380', '8', '#FFF');
                    so.addParam('wmode', 'transparent');
                    so.addParam('allowfullscreen','true');
                    so.addParam('flashvars','file=<?=$code?>&streamer=http://<? echo $input[$rand_keys[0]];?>/ctl/video/xmoov.reader.php?cmf=T0RRMk1EQXhNak15TkRZeE1qVXdPREUyTmpBNE5EWXdNQT09&bts=Tinh.In&backcolor=0x000000&frontcolor=0xCCCCCC&lightcolor=0x557722&autostart=true&shuffle=false&repeat=list&logo=http://vietxem.net/Vietxem.png&image=');
                    so.write('KGTPlayer');
                    </script>
</center>		

			</ul>
	<div class='clear'></div>


</div>
</div>

<div class='box_left'>
						


                                              <div class='bar'>
							<h3><a href='#'>Các Tập Tiếp Theo</a></h3>
						</div>
						<div class='cont'>
							<ul>
			

<?php
function htmltxt($document){
$search = array('@<script[^>]*?>.*?</script>@si',
               '@<[\/\!]*?[^<>]*?>@si',
               '@<style[^>]*?>.*?</style>@siU',
               '@<![\s\S]*?--[ \t\n\r]*>@' 
);
$text = preg_replace($search, '', $document);
return $text;
}
// tim kiếm
$id 		= $_GET['id'];
$id 		= str_replace ('/', '/', $id );

if($id) {
$tim_kiem 	= "http://megafun.vn/".$id;
if(!$id)$tim_kiem="http://megafun.vn/giai-tri/phim-hai/201008/Tuyet-dinh-cong-phu-89761/";
$file 		= file_get_contents($tim_kiem);

	$url_song = explode('<td class="">', $file);
	$total_linksx = count($url_song);
    $total_links = $total_linksx-1;

for ($i=1;$i<=$total_links;$i++) {
	$song = explode('<h3>', $url_song[$i]);
        $song = explode('</h3>', $song[1]);
	$song = htmltxt($song[0]);
	$images = explode('<img src="/dataimages/', $url_song[$i]);
	$images = explode('"', $images[1]);
	$images  = $images[0];
	$url_video = explode('href="/', $url_song[$i]);
	$url_video = explode('/"', $url_video[1]);
	$url_video  = $url_video[0];

    ?>
                               <li>
				<div class='pic'>
					<a href="javascript:void(0);" onClick="window.open('phimboplay/<? echo $url_video;?>/','_main')">
                                       <img class='thumb' src='http://megafun.vn/dataimages/<? echo $images;?>' alt=' '/></a>
					
					
				</div>
				<div class='title'><a href="javascript:void(0);" onClick="window.open('phimboplay/<? echo $url_video;?>/','_main')"><? echo $song;?></a>
                                </div>
				<div class='title'>
					<span class='view_l'>Đang Chiếu</span>
					<span class='view_r star45'></span>
				       </div>
			               </li>


<? } ?>
<? } ?>


			</ul>
	<div class='clear'></div>

</div>
</div>
<div class='box_left'>
						


                                              <div class='bar'>
							<h3><a href='#'>Phim Cùng Thể Loại</a></h3>
						</div>
						<div class='cont'>
							<ul>
<?php
function htmltxt1($document1){
$search1 = array('@<script[^>]*?>.*?</script>@si',
               '@<[\/\!]*?[^<>]*?>@si',
               '@<style[^>]*?>.*?</style>@siU',
               '@<![\s\S]*?--[ \t\n\r]*>@' 
);
$text = preg_replace($search1, '', $document1);
return $text;
}
// tim kiếm
$id 		= $_GET['id'];
$id 		= str_replace ('/', '/', $id );

if($id) {
$tim_kiem1 	= "http://megafun.vn/".$id;
if(!$id)$tim_kiem1="http://megafun.vn/giai-tri/phim-hai/201008/Tuyet-dinh-cong-phu-89761/";
$file1 		= file_get_contents($tim_kiem1);

	$url_song1 = explode('<td><a', $file1);
	$total_linksx = count($url_song1);
    $total_links = $total_linksx-1;

for ($i=1;$i<=$total_links;$i++) {
	$song1 = explode('<h3>', $url_song1[$i]);
        $song1 = explode('</h3>', $song1[1]);
	$song1 = $song1[0];
	$images1 = explode('<img src="/dataimages/', $url_song1[$i]);
	$images1 = explode('"', $images1[1]);
	$images1  = $images1[0];
	$url_video1 = explode('href="/', $url_song1[$i]);
	$url_video1 = explode('/"', $url_video1[1]);
	$url_video1  = $url_video1[0];
    ?>





                            <li>				<div class='pic'>
					<a href="javascript:void(0);" onClick="window.open('phimboplay/<? echo $url_video1;?>/','_main')">
                                       <img class='thumb' src='http://megafun.vn/dataimages/<? echo $images1;?>' alt=' '/></a>
					
					
				</div>
				<div class='title'><a href="javascript:void(0);" onClick="window.open('phimboplay/<? echo $url_video1;?>/','_main')"><? echo $song1;?></a>
                                </div>
				<div class='title'>
					<span class='view_l'>Đang Chiếu</span>
					<span class='view_r star45'></span>
				       </div>
			               </li>

<? } ?>
<? } ?>



			</ul>
	<div class='clear'></div>

</div>
</div>

<div class="clear"></div>
</div>
</div>
</div>


<!-- left -->


<div class="right">
					
					<div class="ads_r">
											</div>
					<div class="box_right">
						<div class="bar">Phim điện ảnh</div>
						<div class="cont">
							<ul>




               <li><a href='phimbomoi/giai-tri/phim-bo/' title='Phim Bộ Mới'>Phim Bộ Mới</a></li>
               <li><a href='' title='Phim Lẻ Mới'>Phim Lẻ Mới</a></li>

               <li><a href='phimle/giai-tri/phim-hanh-dong/' title='Hành Động - Xã Hội Đen'>Hành Động - Xã Hội Đen</a></li>
               <li><a href='phimle/giai-tri/phim-vo-thuat/' title='Võ Thuật - Kiếm Hiệp'>Võ Thuật - Kiếm Hiệp</a></li>
               <li><a href='phimle/giai-tri/phim-tam-ly/' title='Tâm Lý - Tình Cảm'>Tâm Lý - Tình Cảm</a></li>
               <li><a href='phimle/giai-tri/phim-hai/' title='Hài Hước'>Hài Hước</a></li>
               <li><a href='phimle/giai-tri/phim-kinh-di/' title='Kinh Dị - Ma'>Kinh Dị - Ma</a></li>
               <li><a href='phimle/giai-tri/phim-phieu-luu/' title='Phiêu Lưu'>Phiêu Lưu</a></li>
               <li><a href='phimle/giai-tri/phim-khoa-hoc-vien-tuong/' title='Thần Thoại'>Thần Thoại</a></li>
               <li><a href='phimle/giai-tri/phim-khoa-hoc-vien-tuong/' title='Viễn Tưởng'>Viễn Tưởng</a></li>
               <li><a href='phimle/giai-tri/phim-hoat-hinh/' title='Hoạt Hình'>Hoạt Hình</a></li>
               <li><a href='phimle/giai-tri/phim-chien-tranh/' title='Chiến Tranh'>Chiến Tranh</a></li>
               <li><a href='phimle/giai-tri/phim-mien-tay/' title='Phim Cao Bồi'>Phim Cao Bồi</a></li>
               <li><a href='phimle/giai-tri/phim-hinh-su/' title='Phim Hình Sự'>Phim Hình Sự</a></li>
               <li><a href='phimle/giai-tri/phim-ca-nhac/' title='Thể Thao - Âm Nhạc'>Thể Thao - Âm Nhạc</a></li>


               <li><a href='phimbo/giai-tri/phim-bo-viet-nam/' title='Phim Việt Nam'>Phim Việt Nam</a></li>
               <li><a href='phimbo/giai-tri/phim-bo-trung-quoc/' title='Phim Bộ Trung Quốc'>Phim Bộ Trung Quốc</a></li>
               <li><a href='phimbo/giai-tri/phim-bo-dai-loan/' title='Phim Bộ Đài Loan'>Phim Bộ Đài Loan</a></li>
               <li><a href='phimbo/giai-tri/phim-bo-hong-kong/' title='Phim Bộ Hồng Kông'>Phim Bộ Hồng Kông</a></li>
               <li><a href='phimbo/giai-tri/phim-bo-han-quoc/' title='Phim Bộ Hàn Quốc'>Phim Bộ Hàn Quốc</a></li>

</ul>
						</div>
					</div><!-- box_right -->




					<div class="box_right">
						<div class="bar">LIÊN KẾT</div>
						<div class="cont">
							<ul>
								
               <li><a href='http://ebookso1.com' title='Việt Nam'>Ebook Việt</a></li>
               <li><a href='http://vphim.biz' title='Trung Quốc'>Download Phim</a></li>
>							</ul>
						</div>











					

	


				
                                         </ul>
						</div>
					</div><!-- box_right -->
					

				</div><!-- right -->	<div class="clear"></div>
</div><!-- main -->			<div id="footer">
				<div class="valid">
					<a href="#/feed/"><img src="/img/space.gif" class="rss" alt="Rss"/></a>
					<a href=""><img src="/img/space.gif" class="css" alt="Css"/></a>
					<a href=""><img src="/img/space.gif" class="xhtml" alt="XHTML"/></a>
					<a href="#top"><img src="/img/space.gif" class="top" alt="Lên đầu"/></a>
				</div>
				<div class="link">
					<a href="http://vietxem.net/phim/" target="_blank" title="xemphim cự đã">VietXem.Net</a> |
					<a href="http://vietxem.net/phim/" target="_blank" title="Download Phim">Tải Phim</a> |
					<a href="http://vietxem.net/music/" title="">Nghe Nhạc</a> |
					<a target="_blank" title="Phim Mới, Phim Bom Tấn" href="http://vietxem.net/phim/">Phim Mới</a> |
					<a href="http://vietxem.net/phim/" target="_blank" title="Hack Đột Kích - CF - Audition - Hack game Online">Hack Game</a> |
					<a href="http://vietxem.net/phim/" target="_blank" title="Nghe Nhạc">Nghe Nhạc 2</a> |
					<a href="http://laylink.info" title="..::VietXem.Net::..- nghe nhac - video - channel - game - ring - beat karaoke" target="_blank">VietXem.Net</a> |
					<a href="http://vietxem.net/phim/" rel="dofollow" title="Phim bộ, phim bộ Việt Nam, phim bộ Hàn Quốc, Phim bộ HongKong, Phim bộ trung quốc, phim bộ Thái Lan, phim bộ châu âu, phim bộ châu mỹ" target="_blank">VietXem.Net</a> |
					<a href="http://vietxem.net/phim/" title="Kênh thông tin giải trí Hà Giang Vui" target="_blank">VietXem.Net</a> |
					<a rel="dofollow" href="http://vietxem.net/phim" target="_black" title="Phim bộ, phim bộ Việt Nam, phim bộ Hàn Quốc, Phim bộ HongKong, Phim bộ trung quốc, phim bộ Thái Lan, phim bộ châu âu, phim bộ châu mỹ">VietXem.Net</a> |
					<a target="_blank" title="Phim bộ, phim bộ Việt Nam, phim bộ Hàn Quốc, Phim bộ HongKong, Phim bộ trung quốc, phim bộ Thái Lan, phim bộ châu âu, phim bộ châu mỹ" href="http://vietxem.net//phim-bo.html">Phim Bộ</a> |
					<a href="http://vietxem.net/dieu-khoan.html" title="Điều khoản sử dụng">Điều Khoản</a>
				</div>
				<div class="copyright">      


<br/>
					Copyright &copy; 2011 <a href="http://vietxem.net" target="_blank" title="..::VietXem.Net::..">..::VietXem.Net::..</a>, All rights reserved. <br/>
					phát triển code <a href="http://vietxem.net" target="_blank" title="Bởi ..::VietXem.Net::.."><b>Bởi ..::VietXem.Net::..</b></a>.

					
				</div>
			</div>
		</div><!-- wrap -->
	</div><!-- phimso -->
</div>
</div>
<div id="sticky_box"></div>
</body>
</html>